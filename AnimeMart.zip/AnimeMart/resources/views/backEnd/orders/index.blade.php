@extends('backEnd.layouts.master')
@section('title','Order Details')
@section('content')
    <div id="breadcrumb"> <a href="{{url('/admin')}}" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="{{route('orders.index')}}" class="current">Order Details</a></div>
    <div class="container-fluid">
        @if(Session::has('message'))
            <div class="alert alert-success text-center" role="alert">
                <strong>Well done!</strong> {{Session::get('message')}}
            </div>
        @endif
        <div class="widget-box">
            <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                <h5>Order Details</h5>
            </div>
            <div class="widget-content nopadding">
                <table class="table table-bordered data-table">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>Product Size</th>
                        <th>Quantity</th>
                        <th>Orders Status</th>
                        <th>Total Cost</th>
                        <th>Order Date</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($orders as $order)
                        @foreach($items as $item)
                            <tr class="gradeC">
                                <td style="vertical-align: middle;">{{$order->name}}</td>
                                <td style="vertical-align: middle;">{{$order->users_email}}</td>
                                <td style="vertical-align: middle;">{{$order->address}}</td>
                                <td style="vertical-align: middle;">{{$order->city}}</td>
                                <td style="vertical-align: middle;">{{$item->product_code}}</td>
                                <td style="vertical-align: middle;">{{$item->product_name}}</td>
                                <td style="vertical-align: middle;">{{$item->size}}</td>
                                <td style="vertical-align: middle;">{{$item->quantity}}</td>
                                <td style="vertical-align: middle;">{{$order->order_status}}</td>
                                <td style="vertical-align: middle;">{{$order->grand_total}}</td>
                                <td style="vertical-align: middle;">{{$order->created_at}}</td>
                                <td style="text-align: center; vertical-align: middle;">
                                    {{--                                <a href="{{route('product.edit',$user->id)}}" class="btn btn-primary btn-mini">Edit</a>--}}
                                    <a href="javascript:" rel="{{$order->id}}" rel1="cancel-order" class="btn btn-danger btn-mini deleteRecord">Cancel Order</a>
                                </td>
                            </tr>
                        @endforeach
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
@section('jsblock')
    <script src="{{asset('js/jquery.min.js')}}"></script>
    <script src="{{asset('js/jquery.ui.custom.js')}}"></script>
    <script src="{{asset('js/bootstrap.min.js')}}"></script>
    <script src="{{asset('js/jquery.uniform.js')}}"></script>
    <script src="{{asset('js/select2.min.js')}}"></script>
    <script src="{{asset('js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('js/matrix.js')}}"></script>
    <script src="{{asset('js/matrix.tables.js')}}"></script>
    <script src="{{asset('js/matrix.popover.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <script>
        $(".deleteRecord").click(function () {
            var id=$(this).attr('rel');
            var deleteFunction=$(this).attr('rel1');
            swal({
                title:'Do you want to cancel this Order ?',
                text:"You won't be able to revert this!",
                type:'warning',
                showCancelButton:true,
                confirmButtonColor:'#3085d6',
                cancelButtonColor:'#d33',
                confirmButtonText:'Yes',
                cancelButtonText:'No',
                confirmButtonClass:'btn btn-success',
                cancelButtonClass:'btn btn-danger',
                buttonsStyling:false,
                reverseButtons:true
            },function () {
                window.location.href="/admin/"+deleteFunction+"/"+id;
            });
        });
    </script>
@endsection
