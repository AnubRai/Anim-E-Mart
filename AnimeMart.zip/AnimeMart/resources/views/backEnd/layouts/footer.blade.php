<div class="row-fluid">
    <div id="footer" class="span12">Copyright ©Anim-E-Mart Inc. All rights reserved.</div>
</div>
