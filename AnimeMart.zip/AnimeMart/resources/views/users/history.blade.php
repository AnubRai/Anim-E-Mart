@extends('frontEnd.layouts.master')
@section('title','Order History')
@section('slider')
@endsection
@section('content')
    <section id="cart_items">
        <div class="container">
            <div class="table-responsive cart_info">
                <table class="table table-condensed">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>City</th>
{{--                        <th>Product Code</th>--}}
{{--                        <th>Product Name</th>--}}
{{--                        <th>Product Size</th>--}}
{{--                        <th>Quantity</th>--}}
                        <th>Orders Status</th>
                        <th>Total Cost</th>
                        <th>Order Date</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($orders as $order)
{{--                        @foreach($items as $item)--}}
                            <tr class="gradeC">
                                <td style="vertical-align: middle;">{{$order->name}}</td>
                                <td style="vertical-align: middle;">{{$order->users_email}}</td>
                                <td style="vertical-align: middle;">{{$order->address}}</td>
                                <td style="vertical-align: middle;">{{$order->city}}</td>
{{--                                <td style="vertical-align: middle;">{{$item->product_code}}</td>--}}
{{--                                <td style="vertical-align: middle;">{{$item->product_name}}</td>--}}
{{--                                <td style="vertical-align: middle;">{{$item->size}}</td>--}}
{{--                                <td style="vertical-align: middle;">{{$item->quantity}}</td>--}}
                                <td style="vertical-align: middle;">{{$order->order_status}}</td>
                                <td style="vertical-align: middle;">{{$order->grand_total}}</td>
                                <td style="vertical-align: middle;">{{$order->created_at}}</td>
                            </tr>
                        @endforeach
{{--                    @endforeach--}}
                    </tbody>
                </table>
            </div>
        </div>
@endsection
