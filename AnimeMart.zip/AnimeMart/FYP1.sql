-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2021 at 10:32 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fyp`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) UNSIGNED NOT NULL,
  `products_id` int(11) NOT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `user_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `products_id`, `product_name`, `product_code`, `product_color`, `size`, `price`, `quantity`, `user_email`, `session_id`, `created_at`, `updated_at`) VALUES
(10, 1, 'Akatsuki Cloak', 'SKU', 'Black & Red', 'M', 2500.00, 1, 'weshare@gmail.com', 'XU6gff7ORlTzSz162H6VFrYEs1hOSxXISoZpsU5p', '2021-04-11 02:45:54', '2021-04-11 02:45:54');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `name`, `description`, `url`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 0, 'Clothes', 'Clothes Merchandise', 'http://127.0.0.1:8000/clothes', 1, NULL, '2021-04-06 05:16:44', '2021-04-06 05:16:44'),
(2, 0, 'Figurines', 'Anime Figurines', 'http://127.0.0.1:8000/figurines', 1, NULL, '2021-04-06 05:18:48', '2021-04-06 05:18:48'),
(3, 0, 'Stationary Items', 'Anime based Stationary Items', 'http://127.0.0.1:8000/stationary-items', 1, NULL, '2021-04-06 05:27:12', '2021-04-06 05:27:12'),
(4, 1, 'Cosplay Clothes', 'Clothes for Cosplaying different Anime Characters', 'http://127.0.0.1:8000/clothes/cosplay-clothes', 1, NULL, '2021-04-06 05:30:22', '2021-04-06 05:30:22'),
(5, 0, 'Accessories', 'Anime based accessories for decoration.', 'http://127.0.0.1:8000/accessories', 1, NULL, '2021-04-06 05:42:40', '2021-04-06 05:42:40'),
(6, 0, 'Household', 'Anime household merchandise for house decorations.', 'http://127.0.0.1:8000/household', 1, NULL, '2021-04-06 05:48:19', '2021-04-06 05:48:19');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `country_code` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` int(10) UNSIGNED NOT NULL,
  `coupon_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `amount_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiry_date` date NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `delivery_address`
--

CREATE TABLE `delivery_address` (
  `id` int(10) UNSIGNED NOT NULL,
  `users_id` int(11) NOT NULL,
  `users_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pincode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_10_20_040609_create_categories_table', 1),
(4, '2018_10_24_075802_create_products_table', 1),
(5, '2018_11_08_024109_create_product_att_table', 1),
(6, '2018_11_20_055123_create_tblgallery_table', 1),
(7, '2018_11_26_070031_create_cart_table', 1),
(8, '2018_11_28_072535_create_coupons_table', 1),
(9, '2018_12_01_042342_create_countries_table', 1),
(10, '2018_12_03_043804_add_more_fields_to_users_table', 1),
(11, '2018_12_03_093548_create_delivery_address_table', 1),
(12, '2018_12_05_024718_create_orders_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `users_id` int(11) NOT NULL,
  `users_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pincode` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_charges` double(8,2) NOT NULL,
  `coupon_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coupon_amount` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grand_total` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `categories_id` int(11) NOT NULL,
  `p_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `categories_id`, `p_name`, `p_code`, `p_color`, `description`, `price`, `image`, `created_at`, `updated_at`) VALUES
(1, 4, 'Akatsuki Cloak', '00001', 'Black & Red', 'High Quality Akatsuki Cloak', 2500.00, '1617852828-akatsuki-cloak.jpg', '2021-04-07 21:48:49', '2021-04-10 23:23:22'),
(2, 1, 'AOT-Jacket', '00002', 'Green', 'Wing Cops Jacket (Attack on Titan)', 2000.00, '1617853848-aot-jacket.jpg', '2021-04-07 22:05:51', '2021-04-10 06:58:29'),
(3, 4, 'Naruto Dress', '00003', 'Orange & Black', 'Naruto Uzumaki Full Set Dress', 3000.00, '1617853897-naruto-dress.jpg', '2021-04-07 22:06:40', '2021-04-10 23:23:08'),
(4, 4, 'Trafalgar Law Full Set Dress', '00004', 'Black & Yellow', 'Law full Dress', 3500.00, '1617853958-trafalgar-law-full-set-dress.jpg', '2021-04-07 22:07:41', '2021-04-10 06:57:56'),
(5, 1, 'One-Punch Man Jacket', '00005', 'yellow', 'Saitama Jacket', 2505.00, '1617875718-one-punch-man-jacket.jpg', '2021-04-08 04:10:21', '2021-04-08 04:10:21'),
(6, 1, 'Nezuko T-Shirt', '00006', 'White', 'White printed Nezuko T-Shirt', 1500.00, '1618113864-nezuko-t-shirt.jpg', '2021-04-10 22:19:26', '2021-04-10 22:19:26'),
(7, 1, 'Tanjiro T-Shirt', '00007', 'White', 'Tanjiro Printed White T-Shirt', 1500.00, '1618113939-tanjiro-t-shirt.jpg', '2021-04-10 22:20:41', '2021-04-10 22:20:41'),
(9, 1, 'BlackClover T-Shirt', '00009', 'White', 'Black Clover Printed White T-Shirt', 1500.00, '1618114085-blackclover-t-shirt.jpg', '2021-04-10 22:23:07', '2021-04-10 22:23:07'),
(10, 1, 'Death Note T-Shirt', '00010', 'Black', 'Death Note Printed Black T-Shirt', 1500.00, '1618114132-death-note-t-shirt.jpg', '2021-04-10 22:23:53', '2021-04-10 22:23:53'),
(11, 1, 'Slam Dunk Shorts', '00011', 'Orange', 'Salm Dunk Shorts', 1250.00, '1618114296-slam-dunk-shorts.jpg', '2021-04-10 22:26:37', '2021-04-10 22:26:37'),
(12, 1, 'Naruto Shorts', '00012', 'White', 'Naruto Shorts', 1250.00, '1618114354-naruto-shorts.jpg', '2021-04-10 22:27:36', '2021-04-10 22:27:36'),
(13, 1, 'Akatsuki Shorts', '00013', 'Black & Red', 'Akatsuki Shorts', 1300.00, '1618114392-akatsuki-shorts.jpg', '2021-04-10 22:28:14', '2021-04-10 22:28:14'),
(14, 2, 'Zoro Figurine', '00014', 'Green', 'High Quality Zoro Figurine', 4500.00, '1618118023-zoro-figurine.jpg', '2021-04-10 23:28:46', '2021-04-10 23:28:46'),
(15, 2, 'Zoro  Swords Figurine', '00015', 'Green', 'High Quality Zoro Figurine&nbsp;', 4000.00, '1618118081-zoro-swords-figurine.jpg', '2021-04-10 23:29:44', '2021-04-10 23:29:44'),
(16, 2, 'Boa Hancock Sexy Figurine', '00016', 'Pink', 'High Quality Sexy Boa Hancock Figurine&nbsp;', 3000.00, '1618118125-boa-hancock-sexy-figurine.jpg', '2021-04-10 23:30:28', '2021-04-10 23:30:28'),
(17, 2, 'Nezuko Figurine', '00017', 'Pink', 'High Quality Nezuko Figurine&nbsp;', 2800.00, '1618118247-nezuko-figurine.jpg', '2021-04-10 23:32:27', '2021-04-10 23:32:27'),
(18, 2, 'Iachi Figurine', '00018', 'Black & Red', 'High Quality Itachhi Figurine&nbsp;', 3800.00, '1618118329-iachi-figurine.jpg', '2021-04-10 23:33:51', '2021-04-10 23:33:51'),
(19, 2, 'Kuroko FIgurine', '00019', 'Black & Red', 'High Quality Kuroko Figurine&nbsp;', 2500.00, '1618118383-kuroko-figurine.jpg', '2021-04-10 23:34:46', '2021-04-10 23:34:46'),
(20, 2, 'Levi Figurine', '00020', 'Black & Green', 'Attack on Titan&nbsp; Levi figurine', 2250.00, '1618119856-levi-figurine.jpg', '2021-04-10 23:59:19', '2021-04-10 23:59:19'),
(21, 6, 'One Piece Bedsheet', '00021', 'Colorful', 'One Piece Bedsheet', 5000.00, '1618120658-one-piece-bedsheet.jpg', '2021-04-11 00:12:41', '2021-04-11 00:12:41'),
(22, 6, 'Anime Themed Carpet', '00022', 'Blue', 'High Quality Carpet', 3200.00, '1618120716-anime-themed-carpet.jpg', '2021-04-11 00:13:39', '2021-04-11 00:13:39'),
(23, 6, 'Luffy Table Lamp', '00023', 'Orange', 'Luffy Table Lamp', 2800.00, '1618120878-luffy-table-lamp.jpg', '2021-04-11 00:16:20', '2021-04-11 00:16:20'),
(24, 6, 'One Piece Pillow', '00024', 'Colorful', 'One Piece Themed Pillow', 1700.00, '1618121006-one-piece-pillow.jpg', '2021-04-11 00:18:28', '2021-04-11 00:25:41'),
(25, 6, 'Naruto Pillow', '00025', 'Orange', 'Naruto Themed Pillow', 1700.00, '1618121504-naruto-pillow.jpg', '2021-04-11 00:26:47', '2021-04-11 00:26:47'),
(26, 3, 'Naruto Bag', '00026', 'Orange', 'Naruto Themed Bag', 2700.00, '1618121625-naruto-bag.jpg', '2021-04-11 00:28:47', '2021-04-11 00:28:47'),
(27, 3, 'Demon Slayer Themed Bag', '00027', 'Green', 'Demon Slayer Themed Bag', 2700.00, '1618121668-demon-slayer-themed-bag.jpg', '2021-04-11 00:29:31', '2021-04-11 00:29:31'),
(28, 3, 'AOT Purse', '00028', 'Green & White', 'AOT themed purse&nbsp;', 1250.00, '1618121722-aot-purse.jpg', '2021-04-11 00:30:25', '2021-04-11 00:30:25'),
(29, 5, 'One Piece Badge (5)', '0029', 'White', '5 pieces of One Piece Badges', 1200.00, '1618121972-one-piece-badge-5.jpg', '2021-04-11 00:34:34', '2021-04-11 00:34:34'),
(30, 5, 'Nezuko Keychain', '00030', 'Pink', 'Nezuko Keychain', 1400.00, '1618122008-nezuko-keychain.jpg', '2021-04-11 00:35:10', '2021-04-11 00:35:10'),
(31, 5, 'Tanjiro Keychain', '00031', 'Green', 'Tanjiro Keychain', 1400.00, '1618122040-tanjiro-keychain.jpg', '2021-04-11 00:35:43', '2021-04-11 00:35:43'),
(32, 5, 'One Piece Badges Logo', '00032', 'Metallic', 'Logo Badge of One piece Characters', 2500.00, '1618122096-one-piece-badges-logo.jpg', '2021-04-11 00:36:38', '2021-04-11 00:36:38'),
(33, 5, 'SAO Handchain', '00033', 'Metallic', 'SAO Handchain&nbsp;', 1100.00, '1618122142-sao-handchain.jpg', '2021-04-11 00:37:25', '2021-04-11 00:37:25'),
(34, 5, 'One Piece Handchain', '00034', 'Orange', 'One Piece Handchain&nbsp;', 1100.00, '1618122185-one-piece-handchain.jpg', '2021-04-11 00:38:07', '2021-04-11 00:38:07');

-- --------------------------------------------------------

--
-- Table structure for table `product_att`
--

CREATE TABLE `product_att` (
  `id` int(10) UNSIGNED NOT NULL,
  `products_id` int(11) NOT NULL,
  `sku` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_att`
--

INSERT INTO `product_att` (`id`, `products_id`, `sku`, `size`, `price`, `stock`, `created_at`, `updated_at`) VALUES
(1, 4, 'CM5F', 'M', 2500.00, 1, '2021-04-07 22:10:13', '2021-04-08 01:19:19'),
(2, 4, 'CL5F', 'L', 2500.00, 1, '2021-04-08 01:18:07', '2021-04-08 01:19:19'),
(3, 1, 'SKU', 'M', 2500.00, 2, '2021-04-08 04:16:26', '2021-04-08 04:16:26'),
(4, 1, 'SKU', 'L', 2500.00, 1, '2021-04-08 04:16:37', '2021-04-08 04:16:37'),
(5, 5, 'SKU', 'L', 2250.00, 2, '2021-04-10 06:58:55', '2021-04-10 06:58:55'),
(6, 3, 'SKU', 'M', 3000.00, 1, '2021-04-10 06:59:13', '2021-04-10 06:59:13'),
(7, 3, 'SKU', 'L', 3000.00, 2, '2021-04-10 06:59:22', '2021-04-10 06:59:22'),
(8, 13, 'SKU', 'M', 1300.00, 2, '2021-04-10 22:28:43', '2021-04-10 22:35:56'),
(9, 13, 'SKU', 'L', 1300.00, 1, '2021-04-10 22:28:51', '2021-04-10 22:35:56');

-- --------------------------------------------------------

--
-- Table structure for table `tblgallery`
--

CREATE TABLE `tblgallery` (
  `id` int(10) UNSIGNED NOT NULL,
  `products_id` int(11) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` tinyint(4) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pincode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `admin`, `remember_token`, `created_at`, `updated_at`, `address`, `city`, `state`, `country`, `pincode`, `mobile`) VALUES
(3, 'Anub Rai', 'rai.anub@yahoo.com', NULL, '$2y$10$FEKJkzW/MEM5gIHIWJxpDO1f.cwR8dl8wCKkkJ8ACuugHyVBn4H/O', 1, 'Tw9qnQ0bA8Z1F5xvssI2VcURtgS4AceTT328As01XNz8FIK8ZuZE1TkHUbfi', '2021-04-06 04:18:01', '2021-04-06 05:02:06', NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Test', 'test@gmail.com', NULL, '$2y$10$m1hZYcuSHvI7kR7dFnP1S.TnBTIA85VDT4d8NRG1zkJ6f5ZH4S2C.', NULL, 'ZF4qCnh9IBgO8xpyd3VVU3Nfp75dNHgcHK4qa0vmP2C0FG8sS0SOTjxbinJE', '2021-04-10 06:23:14', '2021-04-10 22:56:16', NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`name`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_address`
--
ALTER TABLE `delivery_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_att`
--
ALTER TABLE `product_att`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblgallery`
--
ALTER TABLE `tblgallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `delivery_address`
--
ALTER TABLE `delivery_address`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `product_att`
--
ALTER TABLE `product_att`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblgallery`
--
ALTER TABLE `tblgallery`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
