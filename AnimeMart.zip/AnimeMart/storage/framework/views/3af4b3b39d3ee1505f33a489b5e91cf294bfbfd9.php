<?php $__env->startSection('title','Order History'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="cart_items">
        <div class="container">
            <div class="table-responsive cart_info">
                <table class="table table-condensed">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>City</th>




                        <th>Orders Status</th>
                        <th>Total Cost</th>
                        <th>Order Date</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr class="gradeC">
                                <td style="vertical-align: middle;"><?php echo e($order->name); ?></td>
                                <td style="vertical-align: middle;"><?php echo e($order->users_email); ?></td>
                                <td style="vertical-align: middle;"><?php echo e($order->address); ?></td>
                                <td style="vertical-align: middle;"><?php echo e($order->city); ?></td>




                                <td style="vertical-align: middle;"><?php echo e($order->order_status); ?></td>
                                <td style="vertical-align: middle;"><?php echo e($order->grand_total); ?></td>
                                <td style="vertical-align: middle;"><?php echo e($order->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>